var searchData=
[
  ['openresetnotify_5fcallback',['OpenResetNotify_callback',['../mini__client_8c.html#ab65a2ee6875554964f50a5455ba84910',1,'OpenResetNotify_callback(void *Ctx, E_MQC_BEHAVIOR_RESULT Result, uint8_t SrvResCode, bool SessionPresent):&#160;mini_client.c'],['../ssl__client_8c.html#ab65a2ee6875554964f50a5455ba84910',1,'OpenResetNotify_callback(void *Ctx, E_MQC_BEHAVIOR_RESULT Result, uint8_t SrvResCode, bool SessionPresent):&#160;ssl_client.c']]]
];
