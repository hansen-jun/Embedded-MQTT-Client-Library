var searchData=
[
  ['d_5fmqc_5fstr_5fprotocol',['D_MQC_STR_PROTOCOL',['../_m_q_c__core_8c.html#a919133e294c7be1827879b69b3398ab4',1,'MQC_core.c']]],
  ['data',['Data',['../struct___s___m_q_c___u_t_f8___d_a_t_a.html#a6f183b555714685bf2dfdb2e269e8366',1,'_S_MQC_UTF8_DATA']]],
  ['dstaddress',['DstAddress',['../struct___s___p_l_a_t_f_o_r_m___d_a_t_a.html#a6f5b3bbb5d73d15232b14016297197b1',1,'_S_PLATFORM_DATA']]],
  ['dstport',['DstPort',['../struct___s___p_l_a_t_f_o_r_m___d_a_t_a.html#a7eab1d117db1c90f627a752241c0ea34',1,'_S_PLATFORM_DATA']]]
];
