var searchData=
[
  ['malloc_5fwrapper',['malloc_wrapper',['../wrapper_8h.html#a93068e135180aad55ddb9cc545b13df2',1,'wrapper.h']]],
  ['minimum_5fblock_5fsize',['MINIMUM_BLOCK_SIZE',['../_c_l_i_b__heap_8c.html#a8bb89887c78184fcf57d5240b5c0b6e6',1,'CLIB_heap.c']]]
];
