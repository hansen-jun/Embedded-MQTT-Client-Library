var searchData=
[
  ['freefunc',['FreeFunc',['../struct___s___m_q_c___s_e_s_s_i_o_n___h_a_n_d_l_e.html#a7cf7a653eff5c7029aa901701508906c',1,'_S_MQC_SESSION_HANDLE']]]
];
