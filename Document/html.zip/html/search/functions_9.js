var searchData=
[
  ['unlock_5fwrapper',['unlock_wrapper',['../wrapper_8c.html#a94b78a89049898ae6cda3f1f3cb886ca',1,'unlock_wrapper(S_PLATFORM_DATA *Ctx):&#160;wrapper.c'],['../wrapper_8h.html#a94b78a89049898ae6cda3f1f3cb886ca',1,'unlock_wrapper(S_PLATFORM_DATA *Ctx):&#160;wrapper.c']]]
];
