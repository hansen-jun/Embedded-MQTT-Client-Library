var searchData=
[
  ['network_5fclose_5fwrapper',['network_close_wrapper',['../wrapper_8c.html#aa6ba23f031892a616925f719735bc26a',1,'network_close_wrapper(S_PLATFORM_DATA *Ctx):&#160;wrapper.c'],['../wrapper_8h.html#aa6ba23f031892a616925f719735bc26a',1,'network_close_wrapper(S_PLATFORM_DATA *Ctx):&#160;wrapper.c']]],
  ['network_5fopen_5fwrapper',['network_open_wrapper',['../wrapper_8c.html#aeb01f27923522679544816fd1bd3610d',1,'network_open_wrapper(S_PLATFORM_DATA *Ctx):&#160;wrapper.c'],['../wrapper_8h.html#aeb01f27923522679544816fd1bd3610d',1,'network_open_wrapper(S_PLATFORM_DATA *Ctx):&#160;wrapper.c']]]
];
