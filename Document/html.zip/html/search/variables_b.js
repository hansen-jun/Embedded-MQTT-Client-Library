var searchData=
[
  ['openresetfunccb',['OpenResetFuncCB',['../struct___s___m_q_c___s_e_s_s_i_o_n___h_a_n_d_l_e.html#ab870608e31d1b5d06d5ac557853d1ef7',1,'_S_MQC_SESSION_HANDLE']]]
];
