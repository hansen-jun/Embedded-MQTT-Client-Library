var searchData=
[
  ['clib_5fallocator',['CLIB_allocator',['../group__mbed__c__library.html#ga6a62a773ecf8829f2dc9b3d46de277c2',1,'CLIB_def.h']]]
];
