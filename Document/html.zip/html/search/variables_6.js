var searchData=
[
  ['handler',['Handler',['../struct___s___u_s_e_r___d_a_t_a.html#a5b0ee27b14ba41ffdf3e63bbb879e399',1,'_S_USER_DATA']]],
  ['headerdatasize',['HeaderDataSize',['../struct___s___m_q_c___s_e_s_s_i_o_n___c_t_x.html#a08c11333760338ae669a7dd15212ff5b',1,'_S_MQC_SESSION_CTX']]]
];
