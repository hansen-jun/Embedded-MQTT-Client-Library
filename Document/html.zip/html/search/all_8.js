var searchData=
[
  ['keepaliveinterval',['KeepAliveInterval',['../struct___s___m_q_c___s_e_s_s_i_o_n___h_a_n_d_l_e.html#ab7e06b3e03f0b341daebccf71e7d874b',1,'_S_MQC_SESSION_HANDLE']]]
];
