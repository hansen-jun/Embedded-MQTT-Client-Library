var searchData=
[
  ['openresetfunccb',['OpenResetFuncCB',['../struct___s___m_q_c___s_e_s_s_i_o_n___h_a_n_d_l_e.html#ab870608e31d1b5d06d5ac557853d1ef7',1,'_S_MQC_SESSION_HANDLE']]],
  ['openresetnotify_5fcallback',['OpenResetNotify_callback',['../mini__client_8c.html#ab65a2ee6875554964f50a5455ba84910',1,'OpenResetNotify_callback(void *Ctx, E_MQC_BEHAVIOR_RESULT Result, uint8_t SrvResCode, bool SessionPresent):&#160;mini_client.c'],['../ssl__client_8c.html#ab65a2ee6875554964f50a5455ba84910',1,'OpenResetNotify_callback(void *Ctx, E_MQC_BEHAVIOR_RESULT Result, uint8_t SrvResCode, bool SessionPresent):&#160;ssl_client.c']]]
];
