var searchData=
[
  ['heap_5fbits_5fper_5fbyte',['HEAP_BITS_PER_BYTE',['../_c_l_i_b__heap_8c.html#aae7cf2f4d0c675280a1906b3fe7a95ac',1,'CLIB_heap.c']]]
];
