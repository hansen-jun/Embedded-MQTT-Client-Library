var searchData=
[
  ['next',['next',['../struct_s___l_i_s_t___n_o_d_e.html#ab1fb4b44dba76b64047ebe633f8375fc',1,'S_LIST_NODE']]],
  ['nextfreeblock',['NextFreeBlock',['../struct___s___b_l_o_c_k___l_i_n_k.html#afcd19476a0ebd60585d4e28bd445ba06',1,'_S_BLOCK_LINK']]],
  ['node',['Node',['../struct___s___m_q_c___m_s_g___c_t_x.html#a3deb26ffaf7a5b2ac1725a9652f110b7',1,'_S_MQC_MSG_CTX']]]
];
