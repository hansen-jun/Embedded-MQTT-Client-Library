var searchData=
[
  ['authorition',['Authorition',['../struct___s___m_q_c___s_e_s_s_i_o_n___h_a_n_d_l_e.html#aba36036a6b0a742eb8a79e127683adc6',1,'_S_MQC_SESSION_HANDLE']]]
];
